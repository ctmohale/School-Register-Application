<?php include '../php/processing.php'; ?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Ct Mohale">
  <title>SchoolRegister Platform</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/presentation.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

  <!-- Icons -->
  <link rel="stylesheet" href="./assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="./assets/css/argon.css?v=1.2.0" type="text/css">
</head>

<body>
  <!-- Sidenav -->
  <div style="display:<?php echo $mainAdminSection; ?>;">
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand text-primary">
          School <img src="../assets/img/presentation.png" width="30" alt=""> Register
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">
                  <i class="ni ni-tv-2 text-primary"></i>
                  <span class="nav-link-text">Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#studentRecord">
                  <i class="fas fa-users text-primary"></i>
                  <span class="nav-link-text">Students</span>
                </a>
              </li>
              <li class="nav-item" style="display: <?php echo $limitAccess; ?>;">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#teacherRecord">
                  <i class="fas fa-user-tie"></i>
                  <span class="nav-link-text">Teachers</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#studentRegisterMark">
                  <i class="fas fa-clipboard-list text-primary"></i>
                  <span class="nav-link-text">School Register</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#addPoints">
                  <i class="fas fa-chalkboard-teacher"></i>
                  <span class="nav-link-text">Add points</span>
                </a>
              </li>
            </ul>
        </div>
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Navbar links -->
          <?php include './global-form.php'; ?>
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </div>
            </li>
            <li class="nav-item d-sm-none">
              <a class="nav-link" href="#" data-action="search-show" data-target="#navbar-search-main">
                <i class="ni ni-zoom-split-in"></i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ni ni-bell-55"></i>
              </a>
            </li>
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                    <i class="fas fa-user-circle fa-2x"></i>
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo substr(selectAllData($conn,'teacher','NAME','EMAIL',$_SESSION['emailAdmin']),0,1) . ' ' .selectAllData($conn,'teacher','SURNAME','EMAIL',$_SESSION['emailAdmin'] ); ?></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
                <a href="../admin/teachers-records.php?teacherId=<?php echo selectAllData($conn,'teacher','TEACHER_ID','EMAIL',$_SESSION['emailAdmin']); ?>" class="dropdown-item">
                  <i class="ni ni-single-02"></i>
                  <span>My profile</span>
                </a>
                <a href="../index.php?adminLogout=true" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Header -->
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <br>
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Report</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="./dashboard.php"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Student report</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
          </div>
          <div class="row bg-white" style="padding-top:2%; border-radius: 10px;">
            <div class="row">
              
                <div class="col-sm-6">
                    <div class="card-body">
                      <div class="alert alert-success alert-dismissible fade show" style="display:<?php echo $smsSuccess; ?>;" role="alert">
                      <strong>Success!</strong> SMS sent successfully to student parent
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <div class="alert alert-danger alert-dismissible fade show" style="display:<?php echo $smsFail; ?>;" role="alert">
                      <strong>Error!</strong> Faild to send sms, please varify the contact information!
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                        <div class="table-responsive text-dark" style="border-radius: 10px;">
                            <table class="table align-items-center table-light bg-transparent table-flush">
                                <thead class="thead-dark">
                                    <tr>  
                                        <th scope="col" class="sort" data-sort="budget">Score</th>  
                                        <th scope="col" class="sort" data-sort="budget">Subject</th>  
                                        <th scope="col" class="sort" data-sort="budget">Teacher</th>  
                                    </tr>
                                </thead>
                                <tbody class="list ">
                                    <?php while($rowMainStudentRecordPage = $resultMainStudentRecordPage->fetch_assoc()): ?>
                                        <tr>
                                            <td class="budget">
                                                <span class="status"><?php echo $rowMainStudentRecordPage['SCORE_POINT']; ?>
                                            </td>
                                            <td class="budget">
                                            
                                                <span class="status"><?php echo selectAllData($conn,'subject','SUBJ_NAME','SUBJ_CODE',$rowMainStudentRecordPage['SUBJ_CODE']); ?>
                                            </td>
                                            <td class="budget">
                                            
                                                <span class="status"><?php echo selectAllData($conn,'teacher','NAME','TEACHER_ID',$rowMainStudentRecordPage['TEACHER_ID']) . ' ' . selectAllData($conn,'teacher','SURNAME','TEACHER_ID',$rowMainStudentRecordPage['TEACHER_ID']); ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <form method="POST">
                        <button type="submit" name="btnSendStudenOneReport" class="btn btn-primary">Send report</button>
                        </form>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card-body text-center">
                        <br>
                        <br>
                        <br>
                        <br>
                        <div><i class="fas fa-percent fa-5x"> <?php echo $adminTotalAV; ?></i></div>
                        <br>
                        <h4>Total avarage score for the week</h4>
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!-- Page content -->
  </div>
  <!-- Modal students-->
  <?php include './modal.php'; ?>
  <div>
  <div style="display: <?php echo $logOutSession; ?>;">
    <div class="card text-center" style="padding: 5%; margin: 10%;">
      <div class="card-body">
        <a href="../index.php" class="navbar-brand text-primary">
          School <img src="../assets/img/presentation.png" width="30" alt=""> Register
        </a>
        <br>
        Session over! please login again to access the system!
        <br>
        <a href="../index.php">Home</a>
      </div>
    </div>
  </div>
  <!-- Option 1: Bootstrap Bundle with Popper -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>

  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="./assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="./assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.2.0"></script>
</body>

</html>