<form method="POST" class="navbar-search navbar-search-light form-inline mr-sm-3" id="navbar-search-main">
    <div class="form-group mb-0">
        <div class="input-group input-group-alternative input-group-merge">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
            </div>
            <input class="form-control" name="searchData" placeholder="Search" type="text">
        </div>
    </div>
    <button type="submit" name="findStudent" class="close">
        <span aria-hidden="true">Seach</span>
    </button>
</form>