    <!-- Modal students-->
    <div class="modal fade" id="studentRecord" tabindex="-1" aria-labelledby="studentRecordLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="studentRecordLabel">Students registerd</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              
            </div>
            <div class="modal-body">
            <!-- Dark table -->
              <div class="row">
                <div class="col">
                  <div class="card bg-default shadow">
                        <div class="card-header bg-transparent border-0">
                          <h3 class="text-white mb-0">Student records</h3>
                          <span style="float: right;"><button class="btn btn-secondary"  data-bs-toggle="modal" data-bs-target="#registerNewStudents">Register Student</button></span>
                          <span style="float: right; margin: 1%;"><a href="../php/studentReport.php"><i class="fas fa-file-pdf text-white fa-2x"></i></a></span>
                        </div>
                        <div class="table-responsive text-dark">
                          <table class="table align-items-center table-light bg-transparent table-flush">
                            <thead class="thead-dark">
                                  <tr>
                                    <th scope="col" class="sort" data-sort="name">Name</th>
                                    <th scope="col" class="sort" data-sort="budget">Surname</th>  
                                    <th scope="col">Gender</th>
                                    <th scope="col" class="sort" data-sort="completion">Score</th>
                                    <th scope="col" class="sort" data-sort="status">Report</th>
                                    <th scope="col" class="text-center">Record</th>
                                  </tr>
                            </thead>
                            <tbody class="list ">
                              <?php while($row = $resultStudents->fetch_assoc()): ?>
                              <tr>
                                    <th scope="row">
                                      <div class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                              <i class="fas fa-user-circle fa-2x"></i>
                                            </a>
                                            <div class="media-body">
                                              <span class="name mb-0 text-sm"><?php echo $row['NAME']; ?></span>
                                            </div>
                                      </div>
                                    </th>
                                    <td class="budget">
                                      <span class="status"><?php echo $row['SURNAME']; ?>
                                    </td>
                                    <td>
                                      <?php echo $row['GENDER']; ?>
                                    </td>
                                    <td>
                                      <div class="d-flex align-items-center">
                                      <?php 
                                        $sqlAllScorePoints = "SELECT * FROM score WHERE STUDENT_NO = '$row[Student_No]' LIMIT 5";
                                        $resultAllScorePoints = $conn->query($sqlAllScorePoints);
                                        $totalScorePoint = 0;
                                        while($rowAllScorePoints = $resultAllScorePoints->fetch_assoc()) {
                                          $totalScorePoint = $totalScorePoint + $rowAllScorePoints['SCORE_POINT'];
                                        }
                                      ?>
  
                                            <span class="completion mr-2"><?php echo $totalScorePoint . '%'; ?></span>
                                            <div>
                                              <div class="progress">
                                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="<?php echo $totalScorePoint; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $totalScorePoint; ?>%;"></div>
                                              </div>
                                            </div>
                                      </div>
                                    </td>
                                    <td>
                                      <span class="badge-dot mr-4">
                                            <i class="bg-warning"></i>
                                            <a href="student-report.php?studentId=<?php echo $row['Student_No']; ?>"><span class="status">Open</span></a>
                                      </span>
                                    </td>
                                    <td class="text-right">
                                      <a href="record.php?studentIdRecord=<?php echo $row['Student_No']; ?>&parentId=<?php echo $row['PARENT_ID']; ?>" class="btn btn-primary">Open</a>
                                    </td>
                                  </tr>
                              <?php endwhile; ?>
                            </tbody>
                          </table>
                        </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>

    <!-- Modal Teachers-->
    <div class="modal fade" id="teacherRecord" tabindex="-1" aria-labelledby="studentRecordLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="studentRecordLabel">Teachers registerd</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
          <!-- Dark table -->
            <div class="row">
              <div class="col">
                <div class="card bg-default shadow">
                      <div class="card-header bg-transparent border-0">
                        <h3 class="text-white mb-0">Teachers records</h3>
                        <span style="float: right;"><button class="btn btn-secondary"  data-bs-toggle="modal" data-bs-target="#teacherOpenRecord">Register Teacher</button></span>
                      </div>
                      <div class="table-responsive text-dark">
                        <table class="table align-items-center table-light bg-transparent table-flush">
                          <thead class="thead-dark">
                                <tr>
                                  <th scope="col" class="sort" data-sort="name">Name</th>
                                  <th scope="col" class="sort" data-sort="budget">Surname</th>
                                  <th scope="col" class="sort" data-sort="status">Cell No</th>
                                  <th scope="col" class="sort" data-sort="completion">Email</th>
                                  <th scope="col">Record</th>
                                </tr>
                          </thead>
                          <tbody class="list ">
                              <?php while ($row = $resultLectures->fetch_assoc()): ?>
                                <tr>
                                  <th scope="row">
                                    <div class="media align-items-center">
                                          <a href="#" class="avatar rounded-circle mr-3">
                                            <i class="fas fa-user-tie fa-2x"></i>
                                          </a>
                                          <div class="media-body">
                                            <span class="name mb-0 text-sm"><?php echo $row['NAME']; ?></span>
                                          </div>
                                    </div>
                                  </th>
                                  <td class="budget">
                                    <?php echo $row['SURNAME']; ?>
                                  </td>
                                  <td class="budget">
                                    <?php echo $row['CELLPHONE_NO']; ?>
                                  </td>
                                  <td class="budget">
                                    <?php echo $row['EMAIL']; ?>
                                  </td>
                                  <td class="budget">
                                    <a class="btn btn-primary" href="../admin/teachers-records.php?teacherId=<?php echo $row['TEACHER_ID']; ?>">Open record</a>
                                  </td>
                                  <td>
                                </tr>
                                <?php endwhile; ?>
                          </tbody>
                        </table>
                      </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Teachers Add record-->
    <div class="modal fade" id="teacherOpenRecord" tabindex="-1" aria-labelledby="studentRecordLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="studentRecordLabel">Add Lecture</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-4  bg-primary" style="border-radius: 20px;">
                <div >
                  <div class="card-body">
                    <form role="form" method="post">
                      <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative mb-3">
                          <div class="input-group-prepend">
                            <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                          </div>
                          <input class="form-control" oninput="ValidateEmail('email');" id="email" name="email" placeholder="Email" type="email" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                          <div class="input-group-prepend">
                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                          </div>
                          <input class="form-control" oninput="CheckPassword('password');" name="password" id="password" placeholder="Password" type="password" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                          <input class="form-control" oninput="validationText('name');" name="name" id="name" placeholder="Name" type="text" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                          <input class="form-control" oninput="validationText('surname');" name="surname" id="surname" placeholder="Surname" type="text" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                          <input class="form-control" oninput="cellPhoneValidation('cell');" name="cell" id="cell" placeholder="Cell No" type="number" min="0" required>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                          <input class="form-control" oninput="validationText('subject');" name="subject" id="subject" placeholder="Subject" type="text" required>
                        </div>
                      </div>
                      <div class="text-center">
                        <button type="submit" name="addNewLecture" class="btn btn-success" id="btnBtn" style="width:100% !important; margin: 1%;">Add Lecture</button><br>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div class="col-sm-8">
                <div style="border-radius: 20px;">
                  <div class="card-body text-center">
                    <br>
                    <i class="fas fa-user-tie fa-10x"></i>
                    <hr>
                    <h5 class="card-title">Add a new lecture</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Register new student-->
    <div class="modal fade" id="studentRegisterMark" tabindex="-1" aria-labelledby="studentRecordLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="studentRecordLabel">Attendance list</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-8">
                <div class="table-responsive text-dark" style="border-radius: 20px;">
                  <table class="table align-items-center table-light bg-transparent table-flush">
                    <thead class="thead-dark">
                          <tr>
                            <th scope="col" class="sort" data-sort="name">Name</th>
                            <th scope="col" class="sort" data-sort="budget">Surname</th>
                            <th scope="col" class="sort" data-sort="status">Date</th>
                            <th scope="col" class="sort" data-sort="status">Subject</th>
                          </tr>
                    </thead>
                    <tbody class="list ">
                      <?php while($row = $resultAllMarked->fetch_assoc()): ?>
                        <tr>
                            <th scope="row">
                              <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                      <i class="fas fa-user-circle fa-2x"></i>
                                    </a>
                                    <div class="media-body">
                                      <span class="name mb-0 text-sm"><?php echo selectAllData($conn,'student','NAME','Student_No',$row['STUDENT_NO']); ?></span>
                                    </div>
                              </div>
                            </th>
                            <td class="budget">
                              <?php echo selectAllData($conn,'student','SURNAME','Student_No',$row['STUDENT_NO']); ?>
                            </td>
                            <td class="budget">
                              <?php echo $row['ABSENT_DAY']; ?>
                            </td>
                            <td>
                              <span class="badge-dot mr-4">
                                    <i class="bg-success"></i>
                                    <span class="status"><?php echo selectAllData($conn,'subject','SUBJ_NAME','TEACHER_ID',$row['TEACHER_ID']); ?></span>
                              </span>
                            </td>
                          </tr>
                      <?php endwhile; ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="col-sm-4">
                <div style="border-radius: 20px;">
                    <a href="../php/markedReportRegister.php">
                      <div class="card-body text-center">
                        <i class="fas fa-file-pdf fa-5x text-danger"></i>
                        <p class="card-text">Download PDF</p>                     
                      </div>
                    </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Add points -->
    <div class="modal fade" id="addPoints" tabindex="-1" aria-labelledby="studentRecordLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="studentRecordLabel">Add points</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-6">
              <div class="text-center">
                <h2 id="studentRecordLabel">Update student score</h2>
              </div>
              <form method="post">
                <select class="form-select" name="selectedStudent" aria-label="Default select example" style="margin: 1%;" required>
                  <option value="Select a student" selected>Select a student</option>
                  <?php while ($row = $resultAllStudentsA->fetch_assoc()): ?>
                    <option value="<?php echo $row['Student_No']; ?>"><b><?php echo $row['Student_No'] . ' ' . $row['NAME'] . ' ' . $row['SURNAME']; ?></b></option>
                  <?php endwhile; ?>
                </select>
                <select class="form-select" name="selectedScroeType" aria-label="Default select example" style="margin: 1%;" required>
                  <option value="Score type" selected>Score type</option>
                  <option value="MERIT">MERIT</option>
                  <option value="DEMERIT">DEMERIT</option>
                  <option value="DENTENTION">DENTENTION</option>
                </select>
                <div class="text-center" style="padding:3%;">
                  <button class="btn btn-primary" type="submit" name="btnUpdateSccoreBtn" style="width: 60%;">Update score</button>
                </div>
              </form>
              </div>
              <div class="col-sm-6">
                <div style="border-radius: 20px;">
                  <div class="card-body text-center">
                    <i class="fas fa-clipboard-list text-primary fa-5x"></i>
                    <p class="card-text">Rate and student performance</p>
                    <ul class="list-group">
                      <li class="list-group-item d-flex justify-content-between align-items-center">
                      MERIT
                        <span class="badge bg-primary rounded-pill">+ 10 points</span>
                      </li>
                      <li class="list-group-item d-flex justify-content-between align-items-center">
                      DEMERIT
                        <span class="badge bg-primary rounded-pill">- 10 points</span>
                      </li>
                      <li class="list-group-item d-flex justify-content-between align-items-center">
                      DENTENTION
                        <span class="badge bg-primary rounded-pill">- 100 points</span>
                      </li>
                    </ul>
                    <hr>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal student mark registerd-->
    <div class="modal fade" id="registerNewStudents" tabindex="-1" aria-labelledby="studentRecordLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="studentRecordLabel">Add Student record</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form method="POST">
              <div class="row">
                <div class="col-sm-4">
                  <div class="text-center bg-primary text-light" style="padding: 3%; border-radius: 20px 20px 0 0;"><h3 class="text-light">Students Info</h3></div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationText('studentName');" id="studentName" name="studentName" placeholder="Name" type="text" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control"  oninput="validationText('studentSurname');" id="studentSurname" name="studentSurname" placeholder="Surname" type="text" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="idValidation('studentID_No');" id="studentID_No" name="studentID_No" placeholder="ID Number" type="number" required min="0">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationAddress('studentAddress');" id="studentAddress" name="studentAddress" placeholder="Address" type="text" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationPostal('studentCode');" id="studentCode" name="studentCode" placeholder="Postal Code" type="number" required min="0">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="cellPhoneValidation('studentCell');" id="studentCell" name="studentCell" placeholder="Cell No" type="number" required min="0">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="ValidateEmail('studentEmail');" id="studentEmail"  name="studentEmail" placeholder="Email" type="email" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="CheckPassword('studentPassword');" id="studentPassword" name="studentPassword" placeholder="Password" type="password" required>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="text-center bg-light text-light" style="padding: 3%; border-radius: 20px 20px 0 0;"><h3 class="text-dark">Parent Info</h3></div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationText('parentName');" id="parentName" name="parentName" placeholder="Name" type="text" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationText('parentSurname');" id="parentSurname" name="parentSurname" placeholder="Surname" type="text" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="cellPhoneValidation('parentCell');" id="parentCell"  name="parentCell" placeholder="Cell No" type="number" required min="0">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative" >
                      <input class="form-control" oninput="validationAddress('parentAddress');" id="parentAddress" name="parentAddress" placeholder="Address" type="text" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationPostal('parentCode');" id="parentCode" name="parentCode" placeholder="Postal Code" type="number" required min="0">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="validationText('kimName');" id="kimName" name="kimName" placeholder="Next of kin name" type="text" required min="0">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="input-group input-group-merge input-group-alternative">
                      <input class="form-control" oninput="cellPhoneValidation('kimContact');" id="kimContact" name="kimContact" placeholder="Contact No" type="number" required min="0">
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div style="border-radius: 20px;">
                    <div class="card-body text-center">
                      <br>
                      <br>
                      <i class="fas fa-users text-primary fa-5x"></i>
                      <p class="card-text" style="padding: 3%;">Make sure all the input filed are populated with relevent data</p>
                      <button type="submit" name="btnAddStudentWithParent" id="btnBtnB" class="btn btn-success">ADD Student To Database</button>
                      <hr>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal present students-->
    <div class="modal fade" id="presentStudent" tabindex="-1" aria-labelledby="presentStudentLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="presentStudentLabel">Students present</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
          <p>Total : <?php echo mainCountStat($conn,'reg_outcome','PRESENT_DAY', '',date("j, n, Y"),''); ?></p>
            <ul class="list-group list-group-flush">
              <?php while ($row = $resultAllStudentPresentAtSchool->fetch_assoc()): ?>
                <li class="list-group-item"><i class="fas fa-user-alt"></i> <?php echo selectAllData($conn,'student','NAME','Student_No',$row['STUDENT_NO']) . " " . selectAllData($conn,'student','SURNAME','Student_No',$row['STUDENT_NO']); ?></li>
              <?php endwhile; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal present students-->
    <div class="modal fade" id="totalStudent" tabindex="-1" aria-labelledby="totalStudentLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="totalStudentLabel">Total students</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <ul class="list-group list-group-flush">
              <?php while ($row = $resultAllStudentsInSystem->fetch_assoc()): ?>
                <li class="list-group-item"><i class="fas fa-user-alt"></i> <?php echo selectAllData($conn,'student','NAME','Student_No',$row['Student_No']) . " " . selectAllData($conn,'student','SURNAME','Student_No',$row['Student_No']); ?></li>
              <?php endwhile; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal total teachers-->
    <div class="modal fade" id="totalTeacherInSystem" tabindex="-1" aria-labelledby="totalTeacherInSystemLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="totalTeacherInSystemLabel">Total teachers</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>Total : <?php echo mainCountStat($conn,'teacher','','','','',''); ?></p>
            <ul class="list-group list-group-flush">
              <?php while ($row = $resultAllTeachersInSystem->fetch_assoc()): ?>
                <li class="list-group-item"><i class="fas fa-user-tie"></i>  <?php echo $row['NAME'] . " " . $row['SURNAME']; ?></li>
              <?php endwhile; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal total upset-->
    <div class="modal fade" id="allStudentUpsent" tabindex="-1" aria-labelledby="allStudentUpsentLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="allStudentUpsentLabel">Total student upsent</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>Total : <?php echo mainCountStat($conn,'reg_outcome','ABSENT_DAY', '',date("j, n, Y"),''); ?></p>
            <ul class="list-group list-group-flush">
              <?php while ($row = $resultAllStudentUpsent->fetch_assoc()): ?>
                <li class="list-group-item"><i class="fas fa-user-tie"></i>  <?php echo selectAllData($conn,'student','NAME','Student_No',$row['STUDENT_NO']); ?></li>
              <?php endwhile; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="AdminModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="AdminModalLabel" aria-hidden="true">
    <form method="POST">  
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="AdminModalLabel">Admin</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
          <div class="container text-center" style="padding: 2% !important;">
            <i class="fas fa-user-cog fa-2x"></i>
          </div>
            
              <div class="mb-3">
                <input type="email" name="adminUserName" class="form-control" value="<?php echo selectAllData($conn,'admin','UserName','UserName',$_SESSION['emailAdmin']); ?>" placeholder="Email">
              </div>
              <div class="mb-3">
                <input type="password" name="adminPassword" class="form-control" value="<?php echo selectAllData($conn,'admin','Password','UserName',$_SESSION['emailAdmin']); ?>" placeholder="Password">
              </div>
        
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
  
              <button type="submit" name="btnUpdateAdminInfo" class="btn btn-primary">Update profile</button>
         
          </div>
          </form>
        </div>
      </div>
    </div>