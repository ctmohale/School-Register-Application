<?php include '../php/processing.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Ct Mohale">
  <title>SchoolRegister Platform</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/presentation.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

  <!-- Icons -->
  <link rel="stylesheet" href="./assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="./assets/css/argon.css?v=1.2.0" type="text/css">
</head>

<body>
  <!-- Sidenav -->
  <div style="display:<?php echo $mainAdminSection; ?>;">
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand text-primary">
          School <img src="../assets/img/presentation.png" width="30" alt=""> Register
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" href="dashboard.php">
                  <i class="ni ni-tv-2 text-primary"></i>
                  <span class="nav-link-text">Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#studentRecord">
                  <i class="fas fa-users text-primary"></i>
                  <span class="nav-link-text">Students</span>
                </a>
              </li>
              <li class="nav-item" style="display: <?php echo $limitAccess; ?>;">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#teacherRecord">
                  <i class="fas fa-user-tie"></i>
                  <span class="nav-link-text">Teachers</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#studentRegisterMark">
                  <i class="fas fa-clipboard-list text-primary"></i>
                  <span class="nav-link-text">School Register</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#addPoints">
                  <i class="fas fa-chalkboard-teacher"></i>
                  <span class="nav-link-text">Add points</span>
                </a>
              </li>
            </ul>
        </div>
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <?php include './global-form.php'; ?>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </div>
            </li>
            <li class="nav-item d-sm-none">
              <a class="nav-link" href="#" data-action="search-show" data-target="#navbar-search-main">
                <i class="ni ni-zoom-split-in"></i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ni ni-bell-55"></i>
              </a>
            </li>
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                    <i class="fas fa-user-circle fa-2x"></i>
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo substr(selectAllData($conn,'teacher','NAME','EMAIL',$_SESSION['emailAdmin']),0,1) . ' ' .selectAllData($conn,'teacher','SURNAME','EMAIL',$_SESSION['emailAdmin'] ); ?></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
                <a href="../admin/teachers-records.php?teacherId=<?php echo selectAllData($conn,'teacher','TEACHER_ID','EMAIL',$_SESSION['emailAdmin']); ?>" class="dropdown-item">
                  <i class="ni ni-single-02"></i>
                  <span>My profile</span>
                </a>
                <a href="../index.php?adminLogout=true" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Header -->
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <br>
        <div class="alert alert-success" style="display:<?php echo $alertSuccessInsert; ?>">
          Student information has been recorded successfully!
        </div>
        <div class="alert alert-danger" style="display:<?php echo $alertFailInsertEmailExist; ?>">
          A record exist with the email you enterd for a student!
        </div>
        <div class="alert alert-danger" style="display:<?php echo $alertFailInsertParent; ?>">
          Could not insert parent information! please correct your data!
        </div>
        <div class="alert alert-danger" style="display:<?php echo $alertFailInsertStudentInfoError; ?>">
          Found an error on the student info! please correct your data!
        </div>
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Records</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="./dashboard.php"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Student record</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
          </div>
          <div class="row bg-white" style="padding-top:2%; border-radius: 10px;">
            <div class="col-sm-8">
                <div class="card">
                <form method="POST">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class="text-center bg-primary text-light" style="padding: 3%;margin: 1%;"><h3 class="text-light">Students Info</h3></div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentName" placeholder="Name" type="text" rows="1"><?php echo selectAllData($conn,'student','NAME','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentSurname" placeholder="Surname" type="text" rows="1"><?php echo selectAllData($conn,'student','SURNAME','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentID_No" placeholder="ID Number" type="number" rows="1"><?php echo selectAllData($conn,'student','ID_NO','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentAddress" placeholder="Address" type="text" rows="1"><?php echo selectAllData($conn,'student','ADDRESS','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentCode" placeholder="Postal Code" type="number" rows="1"><?php echo selectAllData($conn,'student','CODE','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentCell" placeholder="Cell No" type="number" rows="1"><?php echo selectAllData($conn,'student','CELLPHONE_NO','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentEmail" placeholder="Email" type="email" rows="1"><?php echo selectAllData($conn,'student','EMAIL','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="studentPassword" placeholder="Password" type="password" rows="1"><?php echo selectAllData($conn,'student','PASSWORD','Student_No',$_SESSION['studentIdRecord']); ?></textarea>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="text-center bg-light text-light" style="padding: 3%;margin: 1%; border-radius: 2px 2px 0 0;"><h3 class="text-dark">Parent Info</h3></div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="parentName" placeholder="Name" rows="1" type="text"><?php echo selectAllData($conn,'parent','NAME','PARENT_ID',$_SESSION['parentId']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="parentSurname" placeholder="Surname" rows="1" type="text"><?php echo selectAllData($conn,'parent','SURNAME','PARENT_ID',$_SESSION['parentId']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="parentCell" placeholder="Cell No" rows="1" type="number"><?php echo selectAllData($conn,'parent','CELLPHONE_NO','PARENT_ID',$_SESSION['parentId']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative" >
                            <textarea class="form-control" name="parentAddress" placeholder="Address" rows="1" type="text"><?php echo selectAllData($conn,'parent','ADDRESS','PARENT_ID',$_SESSION['parentId']); ?></textarea>
                        </div>
                        </div>
                        <div class="form-group">
                        <div class="input-group input-group-merge input-group-alternative">
                            <textarea class="form-control" name="parentCode" placeholder="Postal Code" rows="1" type="number"><?php echo selectAllData($conn,'parent','CODE','PARENT_ID',$_SESSION['parentId']); ?></textarea>
                        </div>
                        </div>
                        <button type="submit" name="btnUpdateStudentInfoAdmin" class="btn btn-primary" style="width:100%;">Update Record</button> 
                    </div>
                    </div>
                </form>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card-body text-center">
                    <br>
                    <br>
                    <i class="fas fa-users text-primary fa-5x"></i>
                    <h5 class="card-title">Student</h5>
                    <p class="card-text">By clicking the following button, you will delete a student full record!</p>
                    <form method="POST">
                      <button name="btnDeleteStudentRecord" type="submit" class="btn btn-danger">Delete Record</button>
                    </form>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!-- Page content -->
  </div>
  <?php include './modal.php'; ?>
  </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>

  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="./assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="./assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.2.0"></script>
</body>

</html>